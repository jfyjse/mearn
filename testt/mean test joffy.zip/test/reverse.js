var str="joffy"
revstring=str.split('').reverse().join('') 
console.log(revstring); 
   
