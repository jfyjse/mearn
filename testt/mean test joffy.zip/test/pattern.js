
for(i=0;i<4;i++){
    var star=""
    for(j=0;j<=i;j++){
        star+="* "
        
    }
    console.log(star);
}